#include <iostream>
#include <iomanip>

using namespace std;

int currentHour = 0;
int currentMinute = 0;
int currentSecond = 0;

void addHour() {
	if (currentHour == 23) {
		currentHour = 0;
	}
	else {
		currentHour = currentHour + 1;
	}
}

void addMinute() {
	if (currentMinute == 59) {
		addHour();
		currentMinute = 0;
	}
	else {
		currentMinute = currentMinute + 1;
	}
}

void addSecond() {
	if (currentSecond == 59) {
		addMinute();
		currentSecond = 0;
	}
	else {
		currentSecond = currentSecond + 1;
	}
}

void printClock24(int hour, int minute, int second) {
	cout << "****************************" << endl;
	cout << setfill('0') << "*	24-Hour Clock	   *" << endl;
	cout << setw(2) <<"*	  " << hour << ":"
		 << setw(2) << minute << ":"
		 << setw(2) << second << "	   *" << endl;
	cout << "****************************" << endl;
}
void printClock12(int hour, int minute, int second) {
	cout << "****************************" << endl;
	if (hour < 12) {
		if (hour == 0) {
			hour = 12;
		}
		cout << setfill('0') << "*	12-Hour Clock	   *" << endl;
		cout << setw(2) << "*	 " << hour << ":"
			 << setw(2) << minute << ":"
			 << setw(2) << second << " AM" << "	   *" << endl;
		cout << "****************************" << endl;
	}
	else if (hour == 12) {

		cout << setfill('0') << "*  12-Hour Clock	   *" << endl;
		cout << setw(2) << "*	 " << hour << ":"
			 << setw(2) << minute << ":"
			 << setw(2) << second << " PM" << "	   *" << endl;
		cout << "****************************" << endl;
	}
	else {
		cout << setfill('0') << "*	12-Hour Clock	   *" << endl;
		cout << setw(2) << "*	 " << hour % 12 << ":"
			 << setw(2) << minute << ":"
			 << setw(2) << second << " PM" << "	   *" << endl;
		cout << "****************************" << endl;
	}
	
}


void main() {
	char colon;
	bool validInput = false;
	while (validInput == false) {
		cout << "Enter a 24-Hour time (hh:mm:ss):" << endl;
		cin >> currentHour >> colon >> currentMinute >> colon >> currentSecond;

		if (currentHour >= 0 && currentHour < 24 && currentMinute >= 0 && currentMinute < 60 && currentSecond >= 0 && currentSecond < 60){
			validInput = true;
		}
		else {
			cout << "Invalid input. Enter a valid 24-Hour time." << endl;
		}
	}


	int selection = 0;
	while (selection != 4) {
		printClock24(currentHour, currentMinute, currentSecond);
		printClock12(currentHour, currentMinute, currentSecond);

		cout << "*********** MENU ***********" << endl;
		cout << "* 1) Add One Hour	   *" << endl;
		cout << "* 2) Add One Minute	   *" << endl;
		cout << "* 3) Add One Second	   *" << endl;
		cout << "* 4) Exit Program	   *" << endl;
		cout << "****************************" << endl;

		cin >> selection;

		if (selection == 1) {
			addHour();
		}
		else if (selection == 2) {
			addMinute();
		}
		else if (selection == 3) {
			addSecond();
		}
		else if (selection == 4) {
			cout << "Exit";
			return;
		}
		else {
			cout << "Invalid input... Exiting.";
			return;
		}

	}


}
